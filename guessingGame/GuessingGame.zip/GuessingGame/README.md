# GuessingGame

A simple java program I had to create for my CS 248 class.

Guessing game picks a number at random, and prompts the user to guess the number. The program will decide whether the guess is too high or too low based on the input.

Follow the instructions in the text-based game to play...
