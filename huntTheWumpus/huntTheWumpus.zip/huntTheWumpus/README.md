# huntTheWumpus
A version of the text-based game, "Hunt The Wumpus" for CS248
