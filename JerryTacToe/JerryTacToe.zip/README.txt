On PC, double-click run.bat to start

On Mac/Linux, double-click run.sh to start