javac jerry/*.java
cd jerry
java JTT