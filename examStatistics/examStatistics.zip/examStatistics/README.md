# Exam Statistics
A calculator for exam stats for CS248 class.

Input test scores stored in a file (See example file "exam2.scores") to run class average and other exam statistics.
