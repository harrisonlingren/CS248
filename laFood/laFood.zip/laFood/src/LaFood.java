/**
La Food program - Main class
@author Harrison Lingren
*/

import java.io.*;

public class LaFood
{
  
  /** main class */
	public static void main(String[] args)
		throws IOException
	{
		simLaFood driver= new simLaFood();
		driver.start();
	}
}